MEDIA MACROPAD - RP2040 / CIRCUITPYTHON

WHAT THIS ZIP CONTAINS
- boot.py: enables USB CDC data serial
- code.py: macropad firmware
- config.py: pins and editable shortcuts
- windows_companion.py: Windows song metadata bridge
- requirements-windows.txt: Windows Python dependencies

ASSUMED WIRING
The photo shows 8 keys in a 3x3 arrangement with the top-right matrix
position occupied by the encoder. This firmware uses a 3x3 matrix with
that top-right switch position unused:
  Row 1: Key 1, Key 2, empty
  Row 2: Key 3, Key 5, Key 6
  Row 3: Key 7, Key 8, Key 9
The encoder push switch is Key 4 (mute).

GPIO:
  Matrix rows: GP0, GP1, GP2
  Matrix columns: GP3, GP4, GP5
  Encoder A/B/SW: GP7, GP8, GP9
  SK6812 data: GP10
  OLED I2C SDA/SCL: GP20/GP21

IMPORTANT WIRING NOTE
This code assumes the switch-diode orientation expected by
keypad.KeyMatrix(columns_to_anodes=True). If keys do not register,
check the diode direction and change columns_to_anodes to False.
Do not connect the matrix pins until verifying the actual PCB pinout.
The GPIO choices are an explicit working assumption because the final
schematic/pin labels were not supplied in the chat.

CIRCUITPYTHON SETUP
1. Install CircuitPython for Raspberry Pi Pico / RP2040 on the board.
2. Copy the Adafruit CircuitPython Library Bundle's lib folder contents:
   - adafruit_hid/
   - adafruit_ssd1306.mpy
   - adafruit_display_text/
   - neopixel.mpy
3. Copy boot.py, code.py, and config.py to CIRCUITPY root.
4. If your OLED is SH1106 rather than SSD1306, replace the display driver.
5. Ensure USB HID is enabled in CircuitPython.

WINDOWS COMPANION
1. Install Python 3.
2. Run: py -m pip install -r requirements-windows.txt
3. Find the Pico USB CDC DATA COM port in Device Manager.
4. Run: py windows_companion.py --port COM5
   Replace COM5 with the actual port.

KEY MAP
Key 1: Previous track
Key 2: Play/Pause
Key 3: Next track
Encoder press / Key 4: Mute
Key 5: Open Spotify using Windows Run
Key 6: Win+Shift+S
Key 7: Win+Shift+T
Key 8: config.py CUSTOM_KEY_8
Key 9: config.py CUSTOM_KEY_9
Encoder clockwise/counterclockwise: Volume +/- (direction can be inverted)

CUSTOM SHORTCUTS
Edit config.py:
  CUSTOM_KEY_8 = "ctrl+alt+m"
  CUSTOM_KEY_9 = "ctrl+alt+n"
Supported names include ctrl, shift, alt, win, space, enter, tab,
esc, arrows, home, end, delete, backspace, F1-F12, letters and digits.
Set a custom key to None to disable it.

LIMITATIONS
- Track title, artist, elapsed time and duration come from Windows'
  Global System Media Transport Controls session. Apps must publish
  media-session metadata for this to work.
- The OLED is 128x32; long titles are truncated.
- Volume changes are sent as standard USB consumer-control events.
- Spotify launch uses the Windows Run dialog and the spotify URI/app alias.
- The code does not control playback speed or seek; those can be added.
