# Enable a second USB CDC serial interface for metadata from the Windows companion.
import usb_cdc
usb_cdc.enable(console=True, data=True)
