import time
import json
import board
import busio
import digitalio
import keypad
import displayio
import terminalio
import neopixel
import usb_hid
import usb_cdc

from adafruit_display_text import label
import adafruit_ssd1306
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

import config

# ---------- USB HID ----------
keyboard = Keyboard(usb_hid.devices)
consumer = ConsumerControl(usb_hid.devices)

# ---------- OLED ----------
i2c = busio.I2C(config.OLED_SCL, config.OLED_SDA)
oled = adafruit_ssd1306.SSD1306_I2C(128, 32, i2c)
oled.fill(0)
oled.show()

# ---------- RGB ----------
pixels = neopixel.NeoPixel(
    config.RGB_PIN, config.NUM_PIXELS,
    brightness=config.RGB_BRIGHTNESS, auto_write=False
)
pixels.fill((0, 0, 0))
pixels.show()

# ---------- Matrix ----------
# CircuitPython keypad handles scanning and switch debouncing.
matrix = keypad.KeyMatrix(
    row_pins=config.ROW_PINS,
    column_pins=config.COL_PINS,
    columns_to_anodes=True,
    interval=0.02,
    max_events=32,
)

# ---------- Encoder ----------
enc_a = digitalio.DigitalInOut(config.ENCODER_A)
enc_a.direction = digitalio.Direction.INPUT
enc_a.pull = digitalio.Pull.UP
enc_b = digitalio.DigitalInOut(config.ENCODER_B)
enc_b.direction = digitalio.Direction.INPUT
enc_b.pull = digitalio.Pull.UP
enc_sw = digitalio.DigitalInOut(config.ENCODER_SW)
enc_sw.direction = digitalio.Direction.INPUT
enc_sw.pull = digitalio.Pull.UP

# Quadrature transition table; accumulates four transitions per detent.
QUAD = {
    (0, 1): 1, (1, 3): 1, (3, 2): 1, (2, 0): 1,
    (1, 0): -1, (3, 1): -1, (2, 3): -1, (0, 2): -1,
}
last_ab = (int(not enc_a.value) << 1) | int(not enc_b.value)
encoder_accum = 0
last_encoder_press = True
last_encoder_press_time = 0.0

# ---------- Display state ----------
media = {
    "title": "No media playing",
    "artist": "Connect a media app",
    "position": 0.0,
    "duration": 0.0,
    "playing": False,
    "volume": 0,
}
last_display_update = 0.0
status_message = ""
status_until = 0.0

def show_status(message, seconds=1.2):
    global status_message, status_until
    status_message = message
    status_until = time.monotonic() + seconds
    draw_display()

def fmt_time(seconds):
    seconds = max(0, int(seconds))
    return "{}:{:02d}".format(seconds // 60, seconds % 60)

def draw_display():
    oled.fill(0)
    title = str(media.get("title", "No media"))[:21]
    artist = str(media.get("artist", ""))[:21]
    oled.text(title, 0, 0, 1)
    oled.text(artist, 0, 9, 1)

    duration = float(media.get("duration", 0) or 0)
    position = float(media.get("position", 0) or 0)
    if duration > 0:
        position = min(position, duration)
        elapsed = fmt_time(position)
        remaining = fmt_time(max(0, duration - position))
        # Progress bar: 124 pixels wide, 3 pixels high.
        oled.rect(1, 20, 126, 4, 1)
        fill_width = int(124 * position / duration)
        if fill_width > 0:
            oled.fill_rect(2, 21, fill_width, 2, 1)
        oled.text(elapsed, 0, 26, 1)
        oled.text("-" + remaining, 78, 26, 1)
    else:
        oled.text("LIVE / TIME N/A", 0, 22, 1)

    if time.monotonic() < status_until:
        oled.fill_rect(0, 0, 128, 32, 0)
        oled.text(status_message[:21], 0, 12, 1)
    oled.show()

def set_rgb_for_playback():
    if media.get("playing", False):
        pixels.fill((0, 28, 16))
    else:
        pixels.fill((0, 0, 22))
    pixels.show()

def send_media(code):
    try:
        consumer.send(code)
        return True
    except Exception:
        show_status("HID not ready")
        return False

def send_shortcut(spec):
    """Send a simple + separated key combination, e.g. ctrl+alt+m."""
    if not spec:
        return
    names = {
        "ctrl": Keycode.CONTROL, "control": Keycode.CONTROL,
        "shift": Keycode.SHIFT, "alt": Keycode.ALT,
        "win": Keycode.WINDOWS, "gui": Keycode.GUI,
        "space": Keycode.SPACE, "enter": Keycode.ENTER,
        "tab": Keycode.TAB, "esc": Keycode.ESCAPE,
        "up": Keycode.UP_ARROW, "down": Keycode.DOWN_ARROW,
        "left": Keycode.LEFT_ARROW, "right": Keycode.RIGHT_ARROW,
        "home": Keycode.HOME, "end": Keycode.END,
        "delete": Keycode.DELETE, "backspace": Keycode.BACKSPACE,
    }
    for n in range(1, 13):
        names["f{}".format(n)] = getattr(Keycode, "F{}".format(n))
    keys = []
    for part in spec.lower().split("+"):
        part = part.strip()
        if part in names:
            keys.append(names[part])
        elif len(part) == 1 and part.isalpha():
            keys.append(getattr(Keycode, part.upper()))
        elif len(part) == 1 and part.isdigit():
            keys.append(getattr(Keycode, "KEYPAD_{}".format(part)))
        else:
            show_status("Bad shortcut")
            return
    if keys:
        keyboard.press(*keys)
        time.sleep(0.04)
        keyboard.release_all()

def launch_spotify():
    # Uses Windows Run dialog; no companion-app dependency.
    keyboard.press(Keycode.WINDOWS, Keycode.R)
    time.sleep(0.12)
    keyboard.release_all()
    time.sleep(0.25)
    keyboard.write("spotify")
    keyboard.press(Keycode.ENTER)
    keyboard.release_all()
    show_status("Opening Spotify")

def handle_key(number):
    # Physical matrix row-major positions:
    # 0,1 = top row; 3,4,5 = middle; 6,7,8 = bottom.
    # Matrix position 2 is empty.
    if number == 0:  # Key 1
        send_media(ConsumerControlCode.SCAN_PREVIOUS_TRACK)
        show_status("Previous track")
    elif number == 1:  # Key 2
        send_media(ConsumerControlCode.PLAY_PAUSE)
        show_status("Play / Pause")
    elif number == 3:  # Key 3
        send_media(ConsumerControlCode.SCAN_NEXT_TRACK)
        show_status("Next track")
    elif number == 4:  # Key 5
        launch_spotify()
    elif number == 5:  # Key 6
        send_shortcut("win+shift+s")
        show_status("Snipping Tool")
    elif number == 6:  # Key 7
        send_shortcut("win+shift+t")
        show_status("Win + Shift + T")
    elif number == 7:  # Key 8
        send_shortcut(config.CUSTOM_KEY_8)
        show_status("Custom key 8")
    elif number == 8:  # Key 9
        send_shortcut(config.CUSTOM_KEY_9)
        show_status("Custom key 9")

def read_companion_serial():
    """Read newline-delimited JSON updates from Windows companion."""
    if usb_cdc.data is None:
        return
    try:
        while usb_cdc.data.in_waiting:
            raw = usb_cdc.data.readline()
            if not raw:
                break
            try:
                packet = json.loads(raw.decode("utf-8").strip())
                media.update(packet)
                set_rgb_for_playback()
                draw_display()
            except Exception:
                pass
    except Exception:
        pass

def handle_encoder():
    global last_ab, encoder_accum, last_encoder_press, last_encoder_press_time
    a = int(not enc_a.value)
    b = int(not enc_b.value)
    current = (a << 1) | b
    if current != last_ab:
        encoder_accum += QUAD.get((last_ab, current), 0)
        last_ab = current
        if encoder_accum >= 4:
            encoder_accum = 0
            if config.ENCODER_CLOCKWISE_UP:
                send_media(ConsumerControlCode.VOLUME_INCREMENT)
            else:
                send_media(ConsumerControlCode.VOLUME_DECREMENT)
            show_status("Volume up" if config.ENCODER_CLOCKWISE_UP else "Volume down", 0.55)
        elif encoder_accum <= -4:
            encoder_accum = 0
            if config.ENCODER_CLOCKWISE_UP:
                send_media(ConsumerControlCode.VOLUME_DECREMENT)
            else:
                send_media(ConsumerControlCode.VOLUME_INCREMENT)
            show_status("Volume down" if config.ENCODER_CLOCKWISE_UP else "Volume up", 0.55)

    pressed = enc_sw.value
    now = time.monotonic()
    if last_encoder_press and not pressed and now - last_encoder_press_time > 0.25:
        # Encoder press = logical Key 4: mute/unmute.
        send_media(ConsumerControlCode.MUTE)
        show_status("Mute / Unmute")
        last_encoder_press_time = now
    last_encoder_press = pressed

draw_display()
set_rgb_for_playback()

while True:
    event = matrix.events.get()
    if event and event.pressed:
        handle_key(event.key_number)

    handle_encoder()
    read_companion_serial()

    now = time.monotonic()
    # Advance displayed elapsed time locally between companion updates.
    if media.get("playing", False) and now - last_display_update >= 1.0:
        media["position"] = min(
            float(media.get("duration", 0) or 0),
            float(media.get("position", 0) or 0) + 1.0
        )
        draw_display()
        last_display_update = now

    if status_message and now >= status_until:
        status_message = ""
        draw_display()

    time.sleep(0.005)
