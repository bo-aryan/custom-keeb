# Media macropad pinout and user-editable shortcuts.
# Assumed 3x3 matrix: top row has 2 switches (last position empty),
# middle and bottom rows have 3 switches each.
#
# Matrix rows: GP0, GP1, GP2
# Matrix cols: GP3, GP4, GP5
# Encoder A/B/SW: GP7, GP8, GP9
# SK6812 data: GP10
# OLED I2C: SDA GP20, SCL GP21

import board

ROW_PINS = (board.GP0, board.GP1, board.GP2)
COL_PINS = (board.GP3, board.GP4, board.GP5)
ENCODER_A = board.GP7
ENCODER_B = board.GP8
ENCODER_SW = board.GP9
RGB_PIN = board.GP10
OLED_SDA = board.GP20
OLED_SCL = board.GP21

NUM_PIXELS = 10
RGB_BRIGHTNESS = 0.12

# Matrix positions are row-major:
# [0, 1, 2] = top row; [3, 4, 5] = middle; [6, 7, 8] = bottom.
# Position 2 is physically empty.
#
# Key 1 = previous, Key 2 = play/pause, Key 3 = next.
# Encoder press = mute (logical Key 4).
# Key 5 = launch Spotify, Key 6 = Win+Shift+S,
# Key 7 = Win+Shift+T, Keys 8 and 9 are configurable.
#
# For configurable keys, use strings such as:
#   "ctrl+alt+m", "win+shift+left", "f13", "alt+tab"
# Set to None to disable.
CUSTOM_KEY_8 = "ctrl+alt+m"
CUSTOM_KEY_9 = "ctrl+alt+n"

# If True, clockwise encoder steps are volume up.
ENCODER_CLOCKWISE_UP = True
