"""
Windows media-session companion for the RP2040 macropad.

Install:
    py -m pip install pyserial winsdk

Run:
    py windows_companion.py --port COM5

Find the Pico's DATA serial COM port in Windows Device Manager.
The Pico's USB CDC data interface is separate from its CircuitPython console.
"""
import argparse
import asyncio
import json
import time
import serial

from winsdk.windows.media.control import (
    GlobalSystemMediaTransportControlsSessionManager,
    GlobalSystemMediaTransportControlsSessionPlaybackStatus,
)

def seconds(timespan):
    try:
        return max(0.0, timespan.total_seconds())
    except Exception:
        return 0.0

async def main(port, baud):
    ser = serial.Serial(port, baudrate=baud, timeout=0.05)
    manager = await GlobalSystemMediaTransportControlsSessionManager.request_async()
    last_packet = None
    last_position_update = 0.0

    print("Connected to macropad on", port)
    try:
        while True:
            session = manager.get_current_session()
            packet = {
                "title": "No media playing",
                "artist": "Open Spotify / browser media",
                "position": 0.0,
                "duration": 0.0,
                "playing": False,
            }

            if session is not None:
                try:
                    props = await session.try_get_media_properties_async()
                    timeline = session.get_timeline_properties()
                    playback = session.get_playback_info()
                    packet["title"] = props.title or "Unknown title"
                    packet["artist"] = props.artist or props.album_artist or "Unknown artist"
                    packet["position"] = seconds(timeline.position)
                    packet["duration"] = seconds(timeline.end_time)
                    packet["playing"] = (
                        playback.playback_status ==
                        GlobalSystemMediaTransportControlsSessionPlaybackStatus.PLAYING
                    )
                except Exception:
                    pass

            # Send once per second; position is refreshed from Windows each time.
            encoded = json.dumps(packet, ensure_ascii=False) + "\n"
            if encoded != last_packet or time.monotonic() - last_position_update >= 1.0:
                ser.write(encoded.encode("utf-8"))
                last_packet = encoded
                last_position_update = time.monotonic()

            await asyncio.sleep(0.8)
    finally:
        ser.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True, help="Pico USB CDC DATA port, e.g. COM5")
    parser.add_argument("--baud", type=int, default=115200)
    args = parser.parse_args()
    asyncio.run(main(args.port, args.baud))
